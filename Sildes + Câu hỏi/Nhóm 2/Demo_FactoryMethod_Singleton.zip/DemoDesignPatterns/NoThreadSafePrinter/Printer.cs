﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoThreadSafePrinter
{
  public sealed class Printer
  {
    private static Printer _uniqueInstance;
    private Printer()
    {
    }

    public static Printer GetInstance(string instanceName)
    {
      if (_uniqueInstance == null)
      {
        Console.WriteLine($"{instanceName} printer object created");
        _uniqueInstance = new Printer();
      }
      return _uniqueInstance;
    }
    public void SayComplete()
    {
      Console.WriteLine("Hello");
    }
  }
}
