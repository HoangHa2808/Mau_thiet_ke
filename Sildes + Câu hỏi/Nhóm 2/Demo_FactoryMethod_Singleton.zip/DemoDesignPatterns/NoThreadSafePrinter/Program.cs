﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NoThreadSafePrinter
{
  public class Program
  {
    static void Main(string[] args)
    {
      InitializePrinterObject();
    }

    static void InitializePrinterObject()
    {
      Printer firstPrinterObject = null;
      Printer secondPrinterObject = null;
      Printer thirdPrinterObject = null;

      Task task1 = Task.Factory.StartNew(() =>
      {
        firstPrinterObject = Printer.GetInstance("First");
      });
      Task task2 = Task.Factory.StartNew(() =>
      {
        secondPrinterObject = Printer.GetInstance("Second");
      });
      Task task3 = Task.Factory.StartNew(() =>
      {
        thirdPrinterObject = Printer.GetInstance("Third");
      });
      Task.WaitAll(task1, task2, task3);

      Console.WriteLine("All threads complete");
      Console.WriteLine("Are these First Printer Object And Second Printer Object Same - {0} ", firstPrinterObject.Equals(secondPrinterObject) ? "Yes" : "No");
      Console.WriteLine("Are these First Printer Object And Third Printer Object Same - {0} ", firstPrinterObject.Equals(thirdPrinterObject) ? "Yes" : "No");
      Console.WriteLine("Are these Second Printer Object And Third Printer Object Same - {0} ", secondPrinterObject.Equals(thirdPrinterObject) ? "Yes" : "No");
      Console.ReadKey();
    }
  }
}
