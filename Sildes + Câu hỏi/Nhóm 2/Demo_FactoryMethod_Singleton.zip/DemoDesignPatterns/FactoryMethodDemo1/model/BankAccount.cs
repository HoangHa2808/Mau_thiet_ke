﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodDemoOne.model
{
  public abstract class BankAccount
  {
    public abstract void validateUserIdentity();
    public abstract void calculateInterestRate();
    public abstract void registerAccount();
  }
}
