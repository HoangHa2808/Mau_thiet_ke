﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodDemoOne.model.factory
{
  public class ConcreteBankAccountFactory : BankAccountFactory
  {
    public override BankAccount createAccount(String type)
    {
      BankAccount bankAccount = null;
      if (type.Equals("P"))
      {
        bankAccount = new PersonalAccount();
      }
      else if (type.Equals("B"))
      {
        bankAccount = new BusinessAccount();
      }
      else if (type.Equals("C"))
      {
        bankAccount = new CheckingAccount();
      }
      else
      {
        Console.WriteLine("Invalid Input");
      }
      return bankAccount;
    }
  }
}
