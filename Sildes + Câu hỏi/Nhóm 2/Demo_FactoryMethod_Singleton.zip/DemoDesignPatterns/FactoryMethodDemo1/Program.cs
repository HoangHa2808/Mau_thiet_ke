﻿using FactoryMethodDemoOne;
using FactoryMethodDemoOne.model;
using FactoryMethodDemoOne.model.factory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodDemo1
{
  internal class Program
  {
    static void Main(string[] args)
    {
      BankAccount bankAccount = null;
      Console.WriteLine("Please enter\n" +
                              " P for Personal account\n" +
                              " B for Business account\n" +
                              " C for Checking account\n" +
                      "----------------------------");
      Console.Write("Input: ");
      String type = Console.ReadLine();

      Client client = new Client(new ConcreteBankAccountFactory());

      bankAccount = client.openAccount(type);

      Console.ReadKey();
    }
  }
}
