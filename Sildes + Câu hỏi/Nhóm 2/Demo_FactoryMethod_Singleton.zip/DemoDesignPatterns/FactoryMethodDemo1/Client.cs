﻿using FactoryMethodDemoOne.model;
using FactoryMethodDemoOne.model.factory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodDemoOne
{
  public class Client
  {
    private ConcreteBankAccountFactory bankAccountFactory;

    public Client(ConcreteBankAccountFactory bankAccountFactory)
    {
      this.bankAccountFactory = bankAccountFactory;
    }

    public BankAccount openAccount(String type)
    {
      BankAccount bankAccount = null;
      bankAccount = bankAccountFactory.createAccount(type);
      bankAccount.validateUserIdentity();
      bankAccount.calculateInterestRate();
      bankAccount.registerAccount();
      return bankAccount;
    }
  }
}
