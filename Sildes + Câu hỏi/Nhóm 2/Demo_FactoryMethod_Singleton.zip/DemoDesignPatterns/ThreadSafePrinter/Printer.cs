﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreadSafePrinter
{
  public sealed class Printer
  {
    private static volatile Printer _uniqueInstance;
    private static readonly object _lockObject = new object();
    private Printer()
    {
    }

    public static Printer GetInstance(string instanceName)
    {
      if (_uniqueInstance == null)
      {
        lock (_lockObject)
        {
          if (_uniqueInstance == null)
          {
            Console.WriteLine($"{instanceName} printer object created");
            _uniqueInstance = new Printer();
          }
        }
      }
      return _uniqueInstance;
    }
  }
}
