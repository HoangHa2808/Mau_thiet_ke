﻿using Demo2.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2
{
  internal class Program
  {
    static void Main(string[] args)
    {
      BankAccount bankAccount = null;
      Console.WriteLine("Please enter\n" +
                              " P for Personal account\n" +
                              " B for Business account\n" +
                              " C for Checking account\n" +
                      "----------------------------");
      Console.Write("Input: ");
      String type = Console.ReadLine();


      Console.WriteLine("Please enter\n 1 for local \n 2 for foreign\n ---------------");
      Console.Write("Input: ");
      int region = int.Parse(Console.ReadLine());


      Client client = new Client();
      bankAccount = client.openAccount(type, region);

      Console.ReadKey();
    }
  }
}
