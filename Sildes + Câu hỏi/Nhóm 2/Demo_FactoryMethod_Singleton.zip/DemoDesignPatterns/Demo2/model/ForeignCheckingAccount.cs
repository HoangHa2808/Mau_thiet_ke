﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2.model
{
  public class ForeignCheckingAccount: BankAccount
  {
    String name = "Foreign Checking account";

    public override void calculateInterestRate()
    {
      Console.WriteLine($"{name}: Calculating interest rate");
    }

    public override void registerAccount()
    {
      Console.WriteLine($"{name}: Registering account");
    }

    public override void validateUserIdentity()
    {
      Console.WriteLine($"{name}: Validating identity");
    }
  }
}
