﻿using Demo2.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace Demo2
{
  public class Client
  {

    public Client()
    {
    }

    public BankAccount openAccount(String type, int region)
    {
      BankAccount bankAccount = null;

      if (type.Equals("P") && region == 2)
      {
        bankAccount = new ForeignPersonalAccount();
      }
      else if (type.Equals("B") && region == 2)
      {
        bankAccount = new ForeignBusinessAccount();
      }
      else if (type.Equals("C") && region == 2)
      {
        bankAccount = new ForeignCheckingAccount();
      }
      else if (type.Equals("P") && region == 1)
      {
        bankAccount = new ForeignPersonalAccount();
      }
      else if (type.Equals("B") && region == 1)
      {
        bankAccount = new ForeignBusinessAccount();
      }
      else if (type.Equals("C") && region == 1)
      {
        bankAccount = new ForeignCheckingAccount();
      }
      else
      {
        Console.WriteLine("Invalid Input");
      }

      bankAccount.validateUserIdentity();
      bankAccount.calculateInterestRate();
      bankAccount.registerAccount();
      return bankAccount;
    }
  }
}
