﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EagerInit
{
  public sealed class Printer
  {
    private static readonly Printer _uniqueInstance = new Printer();
    private Printer()
    {
      Console.WriteLine("Printer Object Was Created");
    }

    public static Printer GetInstance()
    {
      return _uniqueInstance;
    }
  }
}
