﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodDemo2.model.factory
{
  public abstract class BankAccountFactory
  {
    public abstract BankAccount createAccount(String type);
  }
}
