﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodDemo2.model.factory
{
  public class ForeignBankAccountFactory : BankAccountFactory
  {
    public override BankAccount createAccount(string type)
    {
      BankAccount bankAccount = null;
      if (type.Equals("P"))
      {
        bankAccount = new ForeignPersonalAccount();
      }
      else if (type.Equals("B"))
      {
        bankAccount = new ForeignBusinessAccount();
      }
      else if (type.Equals("C"))
      {
        bankAccount = new ForeignCheckingAccount();
      }
      else
      {
        Console.WriteLine("Invalid Input");
      }
      return bankAccount;

    }
  }
}
