﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FactoryMethodDemo2.model.factory;
using FactoryMethodDemo2.model;

namespace FactoryMethodDemo2
{
  public class Program
  {
    static void Main(string[] args)
    {
      BankAccount bankAccount = null;
      Console.WriteLine("Please enter\n" +
                              " P for Personal account\n" +
                              " B for Business account\n" +
                              " C for Checking account\n" +
                      "----------------------------");
      Console.Write("Input: ");
      String type = Console.ReadLine();


      Console.WriteLine("Please enter\n 1 for local \n 2 for foreign\n ---------------");
      Console.Write("Input: ");
      int region = int.Parse(Console.ReadLine());


      if (region == 1)
      {
        Client client = new Client(new LocalBankAccountFactory());
        bankAccount = client.openAccount(type);
      }
      else if (region == 2)
      {
        Client client = new Client(new ForeignBankAccountFactory());
        bankAccount = client.openAccount(type);
      }


      Console.ReadKey();
    }
  }
}
