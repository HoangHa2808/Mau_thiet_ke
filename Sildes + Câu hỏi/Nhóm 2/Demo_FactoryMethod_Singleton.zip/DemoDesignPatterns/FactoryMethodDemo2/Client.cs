﻿using FactoryMethodDemo2.model;
using FactoryMethodDemo2.model.factory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodDemo2
{
  public class Client
  {
    private BankAccountFactory bankAccountFactory;

    public Client(BankAccountFactory bankAccountFactory)
    {
      this.bankAccountFactory = bankAccountFactory;
    }

    public BankAccount openAccount(String type)
    {
      BankAccount bankAccount = null;
      bankAccount = bankAccountFactory.createAccount(type);
      bankAccount.validateUserIdentity();
      bankAccount.calculateInterestRate();
      bankAccount.registerAccount();
      return bankAccount;
    }
  }
}
