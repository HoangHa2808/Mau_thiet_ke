﻿namespace FactoryMethod.Animal
{
    interface IAnimal
    {
        string GetName();
    }
}
